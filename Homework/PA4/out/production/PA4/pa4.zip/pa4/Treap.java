package pa4;
//Jake Talvy
//I pledge my honor that I have abided by the Stevens Honor System.

import java.util.Random;
import java.util.Stack;


public class Treap<E extends Comparable<E>> {
    /**
     * class representing a single node in the pa4.Treap
     * @param <E> generic data type
     */
    private static class Node<E>{
        public E data; // key for the search
        public int priority; // random heap priority
        public Node <E > left;
        public Node <E > right;

        /**
         * creates a new node object
         * @param data the data the node stores
         * @param priority the nodes priority value
         */
        public Node (E data, int priority){
            if (data == null){
                throw new IllegalArgumentException("data cannot be null");
            }
            this.data = data;
            this.priority = priority;
            left = null;
            right = null;
        }

        /**
         * performs a right rotation on the node
         *
         * @return returns the new root node after the rotation
         */
        Node <E> rotateRight (){
            Node<E> newRoot = left;
            this.left = left.right;
            newRoot.right = this;
            return newRoot;
        }

        /**
         * performs a left rotation on the node
         *
         * @return returns the new root node after the rotation
         */
        Node <E> rotateLeft () {
            Node<E> newRoot = right;
            this.right = right.left;
            newRoot.left = this;
            return newRoot;
        }

        public String toString(){
            return "(key =" + data + " , priority =" + priority + ")";
        }
    }
    private Random priorityGenerator;
    private Node<E> root;

    public Treap(){
        root = null;
        priorityGenerator = new Random();
    }
    public Treap(long seed){
        root = null;
        priorityGenerator = new Random(seed);
    }

    public boolean add(E key){
        if (key == null){
            throw new IllegalArgumentException("key cannot be null");
        }
        return add(key, priorityGenerator.nextInt());
    }

    private void reheap(Stack<Node<E>> path){
        Node<E> child = path.pop();
        while (!path.isEmpty()){
            Node<E> newParent;
            Node<E> parent = path.pop();
            if (child.priority < parent.priority){
                return;
            }
            if (parent.right == child){
                newParent = parent.rotateLeft();
            }
            else{
                newParent = parent.rotateRight();
            }
            if(path.isEmpty()){
                root = child;
                return;
            }
            Node<E>grandParent = path.peek();
            if (grandParent.right == parent){
                grandParent.right = newParent;
                parent = grandParent;
            }
            else{
                grandParent.left = newParent;
                parent = grandParent;
            }

        }
    }

    public boolean add(E key, int priority){
        if (key == null){
            throw new IllegalArgumentException("key cannot be null");
        }
        if (root == null){
            root = new Node<E>(key, priority);
            return true;
        }
        Node<E> current = root;
        Stack<Node<E>> path = new Stack<>();
        while(true){
            int comparison = key.compareTo(current.data);
            if (comparison == 0){
                return false;
            }

            path.push(current);

            if (comparison < 0) {
                if (current.left == null) {
                    current.left = new Node<>(key, priority);
                    path.push(current.left);
                    break;
                }
                current = current.left;
            }else {
                if (current.right == null) {
                    current.right = new Node<>(key, priority);
                    path.push(current.right);
                    break;
                }
                current = current.right;
            }
        }
        reheap(path);
        return true;
    }

    boolean delete(E key){
        if (find(key)){
            Node<E> current = root;
            Node<E> parent = root;
            while(true){
                int comparison = key.compareTo(current.data);
                if (comparison == 0){
                    break;
                }
                if (comparison < 0){
                    parent = current;
                    current = current.left;
                }
                else{
                    parent = current;
                    current = current.right;
                }
            }
            boolean rightChild = false;
            while(true){
                rightChild = false;
                if (current.right != null && current.left != null){
                    if (current.right.priority > current.left.priority){
                        parent = current.rotateLeft();
                    }else{
                        parent = current.rotateRight();
                        rightChild = true;
                    }
                }
                if(current.left != null){
                    parent = current.rotateRight();
                    rightChild = true;
                }if (current.right != null){
                    parent = current.rotateLeft();
                }else {
                    if (parent == root){
                        if (parent.right == current){
                            parent.right = null;
                        }else{
                            parent.left = null;
                        }
                    }
                    if (rightChild){
                        parent.right = null;
                    }
                    else{
                        parent.left = null;
                    }
                    return true;
                }
            }
        }
        return false;
    }

    private boolean find(Node<E> root, E key){
        if (key == null){
            throw new IllegalArgumentException("key cannot be null");
        }
        if (root == null){
            return false;
        }
        int comparison = key.compareTo(root.data);
        if (comparison == 0){
            return true;
        }
        if (comparison < 0){
            return find(root.left, key);
        }
        else{
            return find(root.right, key);
        }
    }

    public boolean find(E key){
        return find(root, key);
    }

    public String toString(){
        return toString(root, 0);
    }

    private String toString(Node current, int level){
        StringBuilder s = new StringBuilder();
        for(int i = 0 ; i < level; i++)
            s.append(" ");
        if(current == null)
            s.append("null\n");
        else{
            s.append(current.toString()+"\n");
            s.append(toString(current.left, level + 1));
            s.append(toString(current.right, level + 1));
        }
        return s.toString();
    }
}
